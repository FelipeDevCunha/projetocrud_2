<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD - Loja Elétricos</title>
    <!-- Chamar o CSS dentro do head -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
</head>

<body>
    <nav class="navbar bg-body-tertiary">
        <form class="container-fluid justify-content-start">
            <button class="btn btn-outline-success me-2" type="button"><a href="cadastro.php">Cadastro</a></button>
            <button class="btn btn-sm btn-outline-secondary" type="button"><a href="consulta.php">Consulta</a></button>
        </form>
    </nav>
    <nav>
        <nav class="navbar bg-primary" data-bs-theme="dark">
        </nav>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html