<?php
//  Corrigido: Aspas simples para evitar que o $ seja lido como variável
$host = "localhost";
$user = "felipephp";
$pass = 'senh@321$';
$db = "loja_eletronicos";

// Criando a conexão
$conn = new mysqli($host, $user, $pass, $db);

// Verificando erro
if ($conn->connect_error) {
    // Corrigido: concatenando a variável de erro corretamente se desejar exibir
    die("💀 Erro na conexão: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
echo "Conexão realizada com sucesso!";
