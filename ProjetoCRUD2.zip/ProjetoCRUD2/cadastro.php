<?php
include 'conexao.php'; // Certifique-se que removeu o $conn->close() de dentro dele
include 'menu.php';

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    /*
    Captura os dados do formmulário
    trim() - Remove espaços em branco
    ?? '' é o operador "null coalescing", evita erro se o campo vir vazio
    */
    $nome   = trim($_POST['nome'] ?? '');
    $marca  = trim($_POST['marca'] ?? '');
    $tensao = trim($_POST['tensao'] ?? '');
    $preco_bruto = str_replace(',', '.', trim($_POST['preco'] ?? ''));

    //str_replace() - troca o ',' por '.' para o banco aceitar o decimal
    $preco = str_replace(',', '.', trim($_post['preco'] ?? ''));

    // Validação básica: verifica se os campos essenciais estão vazios
    if (empty($nome) || empty($marca) || empty($tensao)) {
        $mensagem = "<p>Preencha todos os campos obrigatórios 👺</p>";
    } else {
        // Prepara a QUERY SQL usando placerholders (?) por segurança(evita SQL Injection)
        $stmt = $conn->prepare(
            "
                INSERT INTO produtos (nome, marca, voltagem, preco)
                VALUES (?, ?, ?, ?)"
        );

        $stmt->bind_param("sssd", $nome, $marca, $tensao, $preco);

        if ($stmt->execute()) {
            $mensagem = "<p>Produto cadastrado com sucesso!!! 😁🥳🎉</p>";
        } else {
            $mensagem = "<p>☠️☠️☠️Erro ao cadastrar: " . $stmt->error . "</p>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastro de Produtos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css&quot; rel=" stylesheet integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js&quot;" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</head>

<body>
    <h2>Cadastrar Novo Produto</h2>

    <?php echo $mensagem; ?>

    <form method="POST" action="cadastro.php">
        <div class="mb-3">
            <label>Nome do Produto:</label><br>
            <input type="text" class="form-control" name="nome" placeholder="digite o nome do produto"><br><br>
        </div>
        <div class="mb-3">
            <label>Marca:</label><br>
            <input type="text" class="form-control" name="marca" placeholder="digite a marca do produto"><br><br>
        </div>
        <div class="mb-3">
            <label>Tensão (Voltagem):</label><br>
            <input type="text" class="form-control" name="tensao" placeholder="digite a tensão do produto"><br><br>
        </div>
        <div class="mb-3">
            <label>Preço:</label><br>
            <input type="text" class="form-control" name="preco" placeholder="Digite o preço do produto"><br><br>
        </div>
        <button type="submit">Gravar Produto</button>
    </form>
</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js&quot;" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.min.js&quot;" integrity="sha384-G/EV+4j2dNv+tEPo3++6LCgdCROaejBqfUeNjuKAiuXbjrxilcCdDz6ZAVfHWe1Y" crossorigin="anonymous"></script>

</html>