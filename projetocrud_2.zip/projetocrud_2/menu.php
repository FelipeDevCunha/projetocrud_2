<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD - Loja Elétricos</title>
</head>
<body>
    <nav>
        <a href="cadastro.php">Cadastro</a>
        <a href="conexao.php">Consulta</a>


    </nav>
</body>
</html>