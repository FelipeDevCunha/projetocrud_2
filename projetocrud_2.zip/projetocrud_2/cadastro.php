<?php
//Chamando o arquivo para poder inserir dados na tabela produto
include 'conexao.php';
//Chamando o menu.php
include 'menu.php';

//criando variável para mensagem 
$mensagem = "";

//verifica se o formulário foi enviado via metódo POST
if ($_SERVER["REQUEST_METHODO"] === "POST") {
    //captura os dados do formulário
    //trim() - Remove todos os espaços em branco
    //?? - É o operador "null(nulo) coalescing", evita erro se o campo vier vazio

    $nome = trim($_POST['nome'] ?? '');
    $marca = trim($_POST['marca'] ?? '');
    $tensao = trim($_POST['tensao'] ?? '');

    //Retirando os espaços em branco e trocando, por ponto porque o 
    //Banco reconhece como decimal
    $preco = str_replace(',', '.', trim($_POST['preco'] ?? ''));
    //Validação verificando essenciais restão vazios
    if (empty($nome) || empty($marca) || empty($tensao)) {
        $mensagem ="<p =style='color:red>Preencha todos os campos é obrigatório</p>";
    } else {
        //Prepara a QUERY SQL usando placerholder (?) por segurança
        $stmt = $conn->prepare("
        INSERT INTO produtos(nome,marca,voltagem,preco)
        VALUES(?,?,?,?)
        ");

        //Vincular as variáveis aos campos na ordem 
        $stmt->bind_param("sssd",$nome,$marca,$tensao,$preco);

        //Tentando executar a gravação no banco de dados
        if($stmt->execute()){
            $mensagem = "<p style='color:red>Produto cadastrado com sucesso: </p>";
        } else {
            $mensagem = "<p style='color:red>Erro ao cadastrar: " .$stmt->error. "</p>";
        }
        
        //Fechando a declaração preparada parar liberar memória
        $stmt->close();

    }

}

?>
